package com.softec.clientside.views.login;

import android.graphics.Interpolator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.softec.clientside.R;
import com.softec.clientside.views.login.RetrofitRequest.RetrofitClinet;
import com.softec.clientside.views.login.RetrofitRequest.sendLoginData;
import com.softec.clientside.views.login.responseModel.ResponseFromServer;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


    }
}
