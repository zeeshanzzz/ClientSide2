package com.softec.clientside.views.login.RetrofitRequest;

import com.softec.clientside.views.login.responseModel.ResponseFromServer;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

public interface sendLoginData {
    @GET("UserLogin.php")
    Call<ResponseFromServer> getNoticeData(@QueryMap Map<String, String> params);
}
