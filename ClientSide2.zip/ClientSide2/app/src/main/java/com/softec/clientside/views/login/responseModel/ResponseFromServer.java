package com.softec.clientside.views.login.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseFromServer {

@SerializedName("success")
@Expose
private Integer success;
@SerializedName("user")
@Expose
private List<User> user = null;

public Integer getSuccess() {
return success;
}

public void setSuccess(Integer success) {
this.success = success;
}

public List<User> getUser() {
return user;
}

public void setUser(List<User> user) {
this.user = user;
}

}