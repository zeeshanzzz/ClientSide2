package com.softec.clientside.views.login.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class User {

@SerializedName("user_id")
@Expose
private String userId;
@SerializedName("user_first")
@Expose
private String userFirst;
@SerializedName("user_email")
@Expose
private String userEmail;
@SerializedName("user_phone")
@Expose
private String userPhone;
@SerializedName("user_uid")
@Expose
private String userUid;
@SerializedName("user_gender")
@Expose
private String userGender;

public String getUserId() {
return userId;
}

public void setUserId(String userId) {
this.userId = userId;
}

public String getUserFirst() {
return userFirst;
}

public void setUserFirst(String userFirst) {
this.userFirst = userFirst;
}

public String getUserEmail() {
return userEmail;
}

public void setUserEmail(String userEmail) {
this.userEmail = userEmail;
}

public String getUserPhone() {
return userPhone;
}

public void setUserPhone(String userPhone) {
this.userPhone = userPhone;
}

public String getUserUid() {
return userUid;
}

public void setUserUid(String userUid) {
this.userUid = userUid;
}

public String getUserGender() {
return userGender;
}

public void setUserGender(String userGender) {
this.userGender = userGender;
}

}